<?php

return [
    'adminEmail' => 'admin@tokocrypto.com',
    'assetDirApi' => 'https://s2.coinmarketcap.com/static/img/coins/128x128/', //Url Asset from Coinmarket API
];
