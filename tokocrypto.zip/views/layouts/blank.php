
		<!-- Render Content View No Template-->
      <?= $content; ?>



